#!/usr/bin/env python
# -*- coding: utf-8-*-
"""Changing "Superheroes" dictionary values."""

import data

data.SUPERHEROES['Logan']['alias'] = 'Wolverine'

#!/usr/bin/env python
# -*- coding: utf-8-*-
"""Copy object and value into two constants."""

import copy
import task_01.peanut

BUTTER = copy.deepcopy(task_01.peanut.BUTTER)

JELLY = task_01.peanut.BUTTER

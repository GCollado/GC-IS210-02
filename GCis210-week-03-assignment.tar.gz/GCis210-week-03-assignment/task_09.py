#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""A computer that can build the question."""

"""
It is from the Hitchhiker's Guide to Galaxy,a radio series and novel
written Douglash Adam which eventually became a tv series as well as a movie.
"""

THE_ANSWER_TO_EVERYTHING = 42

INFINITE_IMPROBABILITY = 'browning motion'

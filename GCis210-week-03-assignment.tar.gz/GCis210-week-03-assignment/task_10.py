#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Task 10"""

MOVIE = 'dr. strangelove or: how i learned to stop worrying and love the bomb'

ENTITLED = MOVIE.title()

#!/usr/bin/env python
# -*- coding: utf-8 -*_
"""Calculaions the number of weeks in year; WEEKS = 52"""

WEEKS = ((19%10 + 100)+ (2**8))/7

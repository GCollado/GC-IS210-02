#!/usr/env python
#! -*- coding: utf-8 -*-
""""Assignment of simple numeric types using Decimal and Fractions modules."""

from decimal import Decimal
from fractions import Fraction

INTVAL = 1
FLOATVAL = 0.1
DECVAL = Decimal('0.1')
FRACVAL = Fraction(1, 10)

#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Boolean testing using comparison equality (==) and logical AND operators."""

IS_TRUE = True
IS_FALSE = False
IS_NONE = None

INTEGER_EQUIV = IS_TRUE == 1 and IS_FALSE == 0

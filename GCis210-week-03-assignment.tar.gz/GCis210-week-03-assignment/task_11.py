#!/usr/bin/env python
#! -*- coding: utf-8 -*-
"""Prints out the escape sequence of newline, single and double quotations."""


ESCAPE_STRING = '\\' + "n'" + '"'

#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Comparison of catfood with the number of kittens and litterboxes."""

def too_many_kittens(kittens, litterboxes, catfood):
    """returns not (litterboxes >= kittens and catfood)

        Args:
           kittens (int): int number of kittens.
           litterboxes (int): int number of litterboxes.
           catfood (bool): bool to determine if the catfood exists

        Returns:
           inverses the return value.
    """

    return not (litterboxes >= kittens and catfood)

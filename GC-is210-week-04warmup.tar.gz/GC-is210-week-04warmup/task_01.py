#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""This module provides a function that knows what you mean"""

def know_what_i_mean(wink, numwink=2):
    """Multiples string and int arguments which is returned in retstr.

    Args:
        wink (str): string value wink.
        numwink(int): int value for number of winks.

    winks = (wink * numbwink).strip()
    Calculates number of winks by winks as well as removes whitespaces.

    nudges = ('nudge' * numbwink).strip()
    Calculates number of nudges by winks as well as removes whitespaces.

    restr = 'Know what I mean?{}, {}'.format (winks, nudges)
    Takes winks and nudges into a list and formats the results.

    Yields:
        returns retstr.

    Examples:
        >>> print iknow_what_i_mean("wink")
        Know what I mean? wink wink nudge nudge
    """

    winks = (wink * numwink).strip()
    nudges = ('nudge ' * numwink).strip()
    retstr = 'Know what I mean? {}, {}'.format(winks, nudges)
    return retstr
